By Selim Tanriverdi and William Kelley
// CS 3013 C02 2016

Compile project by running

$ make

Test the printout of a valid command by running

$ ./runCommand ls

Test the printout of an invalid command by running

# ./runCommand thisisaninvalidcommand

